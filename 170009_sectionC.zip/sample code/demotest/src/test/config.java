package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class config {
	public static void main(String[] args) {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            @SuppressWarnings("unused")
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","");
            
        }catch(ClassNotFoundException e){
            System.out.println(e);
        }catch(SQLException ex){
            System.out.println(ex);
        }
 
    }

}
